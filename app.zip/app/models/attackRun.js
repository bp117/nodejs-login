import mongoose from 'mongoose';
const Schema = mongoose.Schema;


const ChaosAttacksRunStatusSchema = new Schema({
    attackId: String,
    runId: String,
    chaosId: Object,
    componentStatus: [new Schema({
    componentId: Object,
    instances: [{
    instanceId: Object,
    createDate: Date,
    status: String
    }]
    })]
    },
    {
    timestamps: true
});

export default mongoose.model('AttackRun', ChaosAttacksRunStatusSchema);
