import mongoose from 'mongoose';
const Schema = mongoose.Schema;


const ChaosAttackSchema = new Schema({
    chaosId: String,
    components: [],
    applicationId: String,
    summary: String,
    description:String,
    scheduledTimeStamp: Date,
    stopTimeStamp: Date,
    starTimeStamp: Date,
    createdBy: Object
    },
    {
    timestamps: true
});


export default mongoose.model('Attack', ChaosAttackSchema);
