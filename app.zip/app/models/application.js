import mongoose from 'mongoose';
const Schema = mongoose.Schema;


const ApplicationSchema = new Schema({
    userId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    appName:String,
    remedyAppId:String,
    emailContact:String
});


export default mongoose.model('Application', ApplicationSchema);
