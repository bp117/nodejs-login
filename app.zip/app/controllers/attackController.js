import Responder from '../../lib/expressResponder';
import Attack from '../models/attack';
import _ from "lodash";


export default class AttackController {
  static show(req, res) {
    Attack.find(req.body)
    .then((attack)=> {
    Responder.success(res,attack)
    })
    .catch((err)=>Responder.operationFailed(res,err))
  }

  static create(req, res) {
    Attack.create(req.body)
    .then((attack)=>Responder.success(res,attack))
    .catch((err)=>Responder.operationFailed(res,err))
  }
  static update(req, res) {
    Attack.findOneAndUpdate({_id:req.params.id},{$set:req.body},{new:true})
      .then((val)=>Responder.success(res,val))
      .catch((err)=>Responder.operationFailed(res,err))
  }

  static remove(req, res) {
    Attack.remove({_id:req.params.id})
    .then((attack)=>Responder.success(res,attack))
    .catch((err)=>Responder.operationFailed(res,err))
  }

}
