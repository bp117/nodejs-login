import Responder from '../../lib/expressResponder';
import Instance from '../models/instance';
import _ from "lodash";


export default class InstanceController {
  static show(req, res) {
    Instance.find(req.body)
    .then((instance)=> {
    Responder.success(res,instance)
    })
    .catch((err)=>Responder.operationFailed(res,err))
  }

  static create(req, res) {
    Instance.create(req.body)
    .then((instance)=>Responder.success(res,instance))
    .catch((err)=>Responder.operationFailed(res,err))
  }
  static update(req, res) {
    Instance.findOneAndUpdate({_id:req.params.id},{$set:req.body},{new:true})
      .then((val)=>Responder.success(res,val))
      .catch((err)=>Responder.operationFailed(res,err))
  }

  static remove(req, res) {
    Instance.remove({_id:req.params.id})
    .then((instance)=>Responder.success(res,instance))
    .catch((err)=>Responder.operationFailed(res,err))
  }

}
