import Responder from '../../lib/expressResponder';
import User from '../models/user';
import _ from "lodash";


export default class UserController {
  static show(req, res) {
    User.find(req.body)
    .then((user)=> {
    Responder.success(res,user)
    })
    .catch((err)=>Responder.operationFailed(res,err))
  }

  static create(req, res) {
    User.create(req.body)
    .then((user)=>Responder.success(res,user))
    .catch((err)=>Responder.operationFailed(res,err))
  }
  static update(req, res) {
    User.findOneAndUpdate({_id:req.params.id},{$set:req.body},{new:true})
      .then((val)=>Responder.success(res,val))
      .catch((err)=>Responder.operationFailed(res,err))
  }

  static remove(req, res) {
    User.remove({_id:req.params.id})
    .then((user)=>Responder.success(res,user))
    .catch((err)=>Responder.operationFailed(res,err))
  }

}
