import Responder from '../../lib/expressResponder';
import Release from '../models/release';
import _ from "lodash";


export default class ReleaseController {
  static show(req, res) {
    Release.find(req.body)
    .then((release)=> {
    Responder.success(res,release)
    })
    .catch((err)=>Responder.operationFailed(res,err))
  }

  static create(req, res) {
    Release.create(req.body)
    .then((release)=>Responder.success(res,release))
    .catch((err)=>Responder.operationFailed(res,err))
  }
  static update(req, res) {
    Release.findOneAndUpdate({_id:req.params.id},{$set:req.body},{new:true})
      .then((val)=>Responder.success(res,val))
      .catch((err)=>Responder.operationFailed(res,err))
  }

  static remove(req, res) {
    Release.remove({_id:req.params.id})
    .then((release)=>Responder.success(res,release))
    .catch((err)=>Responder.operationFailed(res,err))
  }

}
