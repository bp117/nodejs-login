import express from 'express';
import UserController from '../controllers/userController';

const initUserRoutes = () => {
  const userRoutes = express.Router();
  userRoutes.get('/', UserController.show);
  userRoutes.post('/', UserController.create);
  userRoutes.put('/:id', UserController.update);
  userRoutes.delete('/:id', UserController.remove);
  return userRoutes;
};

export default initUserRoutes;
