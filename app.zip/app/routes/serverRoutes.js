import express from 'express';
import ServerController from '../controllers/serverController';

const initServerRoutes = () => {
  const serverRoutes = express.Router();
  serverRoutes.get('/', ServerController.show);
  serverRoutes.post('/', ServerController.create);
  serverRoutes.put('/:id', ServerController.update);
  serverRoutes.delete('/:id', ServerController.remove);
  return serverRoutes;
};

export default initServerRoutes;
