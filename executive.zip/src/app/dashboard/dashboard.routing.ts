import { Routes } from '@angular/router';

import { CrmComponent } from './crm/crm.component';

export const DashboardRoutes: Routes = [
   {
      path: '',
      redirectTo: 'executive',
      pathMatch: 'full'
   },
   {
      path: '',
      children: [
       
         {
            path: "executive",
            component : CrmComponent
         }
      ]
   }
];
