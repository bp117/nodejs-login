import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { Events } from 'ionic-angular';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class UsersProvider{

  apiUrl: string = 'http://13.58.165.61:3000/';

  constructor(public http: Http, public events: Events) {
	}
	
  login(data) {
    let headers = new Headers();
    headers.append('Content-Type', "application/json");
    return this.http.post(this.apiUrl + 'authenticate', data, { headers: headers })
      .map(res => res.json());
      // .catch(error => error.json()));
  } 

  register(data) {
    let headers = new Headers();
    headers.append('Content-Type', "application/json");
    return this.http.post(this.apiUrl + 'createUser', data, { headers: headers })
      .map(res => res.json());  //.catch(error => error.json()));
  }
}
