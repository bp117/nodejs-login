import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, AlertController } from 'ionic-angular';
import { LoginPage } from '../login/login';
import { UsersProvider } from '../../providers/users/users';
import { HomePage } from '../home/home';

@IonicPage()
@Component({
  selector: 'page-singup',
  templateUrl: 'singup.html',
})
export class SingupPage {
  formData:any;
  constructor(public navCtrl: NavController, public navParams: NavParams, public auth: UsersProvider, public loadingCtrl: LoadingController,public alertCtrl: AlertController) {
    this.formData = { 
        "user_type": "player"
    }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SingupPage');
  }

  submit(){
    let loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    loading.present();
    this.auth.register(this.formData).subscribe((data) => {
      console.log(data);
		loading.dismiss();
		if(data.user){
      let alert = this.alertCtrl.create({
        title: 'Success',
        subTitle: 'Successfully create account.',
        buttons: ['Dismiss']
      });
      alert.present();
      localStorage.setItem('user_token',data.token);
      localStorage.setItem('users', JSON.stringify(data.user));
      // this.navCtrl.setRoot(HomePage);
		}else{
      let alert = this.alertCtrl.create({
        title: 'Error',
        subTitle: data.message,
        buttons: ['Dismiss']
      });
      alert.present();
    }
    }, (err) => {
      console.log(err);
      let alert = this.alertCtrl.create({
        title: 'Error',
        subTitle: 'Something went worng.',
        buttons: ['Dismiss']
      });
      alert.present();
      loading.dismiss();
    });

  }
  login(){
    this.navCtrl.setRoot(LoginPage);
  }

}
