import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, AlertController } from 'ionic-angular';
import { SingupPage } from '../singup/singup';
import { UsersProvider } from '../../providers/users/users';
import { HomePage } from '../home/home';

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  player: boolean = true;
  formData:any;
  constructor(public navCtrl: NavController, public navParams: NavParams, public auth: UsersProvider, public loadingCtrl: LoadingController,public alertCtrl: AlertController) {
    this.formData= { 
        "email": "",
        "password": ""
    }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }

  singup(){
    this.navCtrl.push(SingupPage);
  }
  active(){
    this.player = !this.player;
  }

  login(){
    let loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    loading.present();
    this.auth.login(this.formData).subscribe((data) => {
      console.log(data);
		loading.dismiss();
		if(data.user || data.success){
      let alert = this.alertCtrl.create({
        title: 'Success',
        subTitle: 'Successfully Login.',
        buttons: ['Dismiss']
      });
      alert.present();
      localStorage.setItem('user_token',data.token);
      localStorage.setItem('users', JSON.stringify(data.user));
		}else{
      console.log("come");
      let alert = this.alertCtrl.create({
        title: 'Error',
        subTitle: data.message,
        buttons: ['Dismiss']
      });
      alert.present();
    }

    }, (err) => {
      console.log(err);
      let alert = this.alertCtrl.create({
        title: 'Error',
        subTitle: 'Something went worng.',
        buttons: ['Dismiss']
      });
      alert.present();
      loading.dismiss();
    });

  }
}
