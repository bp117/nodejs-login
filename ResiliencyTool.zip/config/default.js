import packageJSON from '../package.json';

module.exports = {
  app: {
    version: packageJSON.version,
    title: 'Chaos',
    description: packageJSON.description
  },

  dir_structure: {
    models: 'app/models/**/*.js',
    routes: 'app/routes/**/*Routes.js',
    controllers: 'app/conrollers/**/*Controller.js'
  },

  otpService:{
  
      host: 'http://bulksms.genx-infotech.com',
      AUTH_KEY:'7f1547ae1f47dc1bb0eb7478e2745b71'

  },


  db: {
    uri: `mongodb://localhost/Zobs`,
    options: {
      user: 'root',
      pass: 'p@ssw0rd',
      server: { poolSize: 40 },
      replset: { poolSize: 40 }
    },
    debug: false
  },
};
