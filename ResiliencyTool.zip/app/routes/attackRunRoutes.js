import express from 'express';
import AttackRunController from '../controllers/attackRunController';

const initAttackRunRoutes = () => {
  const attackRunRoutes = express.Router();
  attackRunRoutes.get('/', AttackRunController.show);
  attackRunRoutes.post('/', AttackRunController.create);
  attackRunRoutes.put('/:id', AttackRunController.update);
  attackRunRoutes.delete('/:id', AttackRunController.remove);
  return attackRunRoutes;
};

export default initAttackRunRoutes;
