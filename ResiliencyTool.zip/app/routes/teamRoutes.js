import express from 'express';
import TeamController from '../controllers/teamController';

const initTeamRoutes = () => {
  const teamRoutes = express.Router();
  teamRoutes.get('/', TeamController.show);
  teamRoutes.post('/', TeamController.create);
  teamRoutes.put('/:id', TeamController.update);
  teamRoutes.delete('/:id', TeamController.remove);
  return teamRoutes;
};

export default initTeamRoutes;
