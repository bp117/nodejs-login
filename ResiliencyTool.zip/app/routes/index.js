import initTeamRoutes from './teamRoutes';
import initAttackRoutes from './attackRoutes';
import initAttackRunRoutes from './attackRunRoutes';

const initRoutes = (app) => {
  app.use(`/team`, initTeamRoutes());
  app.use(`/attack`,initAttackRoutes());
  app.use(`/attackRun`, initAttackRunRoutes());
 
  
  // set the static files location /public/img will be /img for users
  // app.get('/', function(req, res) {  });


};

export default initRoutes;
