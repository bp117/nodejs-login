import mongoose from 'mongoose';
const Schema = mongoose.Schema;


const chaosTeamSchema = new Schema({
    teamName: String,
    lob: String,
    subLob: String,
    emailContact: String,
    users: [new Schema({
    userName:String,
    emailContact:String,
    lanId:String,
    userRole: String})],
    applications: [new Schema({
    appName:String,
    remedyAppId:String,
    emailContact:String,
    components: [new Schema({
    componentName:String,
    servers: [new Schema({
    serverName:String,
    release: [new Schema({
    releaseName:String,
    env:String,
    instanceCommands: [new Schema({
    instanceNo:String,
    startupCommand:String,
    shutdownCommand:String,
    queryCommand:String})]
    })]})],
    remedyAppId: String,
    emailContact: String,
    components: [new Schema({
    componentName: String,
    servers: [new Schema({
    serverName: String,
    release: [new Schema({
    releaseName:String,
    env:String,
    instanceCommands: [new Schema({
    instanceNo:String,
    startupCommand:String,
    shutdownCommand:String,
    queryCommand:String})]
    })]})],
    dependencies: [{
    dependencyType: String,
    componentId: Object 
    }]})]})]
    },
    {
    timestamps: true
    })],    
});


export default mongoose.model('Team', chaosTeamSchema);