import mongoose from 'mongoose';
const Schema = mongoose.Schema;


const ChaosAttackSchema = new Schema({
    chaosId: String,
    components: [new Schema({
        componentId: Object,
        priority: Number,
        instances:[{
        type: Object
        }]
    })],
    scheduledTimeStamp: Date,
    stopTimeStamp: Date,
    starTimeStamp: Date,
    createdBy: Object,
    },
    {
    timestamps: true
});


export default mongoose.model('Attack', ChaosAttackSchema);
