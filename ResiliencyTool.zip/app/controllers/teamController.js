import Responder from '../../lib/expressResponder';
import Team from '../models/team';
import _ from "lodash";


export default class TeamController {
  static show(req, res) {
    Team.find(req.body)
    .then((team)=> {
    Responder.success(res,team)
    })
    .catch((err)=>Responder.operationFailed(res,err))
  }

  static create(req, res) {
    Team.create(req.body)
    .then((team)=>Responder.success(res,team))
    .catch((err)=>Responder.operationFailed(res,err))
  }
  static update(req, res) {
    Team.findOneAndUpdate({_id:req.params.id},{$set:req.body},{new:true})
      .then((val)=>Responder.success(res,val))
      .catch((err)=>Responder.operationFailed(res,err))
  }

  static remove(req, res) {
    Team.remove({_id:req.params.id})
    .then((team)=>Responder.success(res,team))
    .catch((err)=>Responder.operationFailed(res,err))
  }

}
