import Responder from '../../lib/expressResponder';
import AttackRun from '../models/attackRun';
import _ from "lodash";


export default class AttackRunController {
  static show(req, res) {
    AttackRun.find(req.body)
    .then((attackRun)=> {
    Responder.success(res,attackRun)
    })
    .catch((err)=>Responder.operationFailed(res,err))
  }

  static create(req, res) {
    AttackRun.create(req.body)
    .then((attackRun)=>Responder.success(res,attackRun))
    .catch((err)=>Responder.operationFailed(res,err))
  }
  static update(req, res) {
    AttackRun.findOneAndUpdate({_id:req.params.id},{$set:req.body},{new:true})
      .then((val)=>Responder.success(res,val))
      .catch((err)=>Responder.operationFailed(res,err))
  }

  static remove(req, res) {
    AttackRun.remove({_id:req.params.id})
    .then((attackRun)=>Responder.success(res,attackRun))
    .catch((err)=>Responder.operationFailed(res,err))
  }

}
