// Register babel
require('babel-register');

var lib = require('./lib');
lib.app.start();

