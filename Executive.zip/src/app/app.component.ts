import {Component, Optional, ViewEncapsulation} from '@angular/core';

@Component({
  	selector: 'exec-app',
   template:`<router-outlet></router-outlet>
   			<ngx-loading-bar></ngx-loading-bar>`,
   encapsulation: ViewEncapsulation.None
})

export class ExecAppComponent {
   constructor() {
    
   }
}
