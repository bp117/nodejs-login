import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule,
			MatButtonModule,
			MatIconModule,
			MatDialogModule,
			MatFormFieldModule,
			MatSelectModule,
			MatMenuModule,
			MatDividerModule,
			MatSnackBarModule,
			MatInputModule,
			MatChipsModule,
			MatListModule,
			MatTableModule,
			MatExpansionModule
		} from '@angular/material';
		import { NgxEchartsModule } from 'ngx-echarts';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { TranslateModule } from '@ngx-translate/core';
import { RouterModule } from '@angular/router';
import { PerfectScrollbarModule, PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';

import { ChartsModule } from 'ng2-charts';
import { LineChartComponent } from './chart/line-chart/line-chart.component';
import { PieChartComponent } from './chart/pie-chart/pie-chart.component';

import { Ng2PieChartComponent } from './chart/ng2-pie-chart/ng2-pie-chart.component';


import { nvD3 } from "../core/nvD3/nvD3.component";
import { FullWidthGraphComponent } from './chart/full-width-graph/full-width-graph.component';
@NgModule({
	declarations: [
		
		LineChartComponent,
		nvD3,
		PieChartComponent,
	
		
		
		FullWidthGraphComponent
	],
	imports: [
		RouterModule,
		ChartsModule,
		CommonModule,
		MatCardModule,
		FlexLayoutModule,
		MatInputModule,
		MatButtonModule,
		MatIconModule,
		MatExpansionModule,
		MatDialogModule,
		MatFormFieldModule,
		MatSelectModule,
		MatMenuModule,
		MatDividerModule,
		FormsModule,
		ReactiveFormsModule,
		MatSnackBarModule,
		TranslateModule,
		MatChipsModule,
		MatListModule,
		PerfectScrollbarModule,
		MatTableModule,
		NgxEchartsModule
	],
	exports: [
	
		LineChartComponent,
		
		PieChartComponent,
	
		
		
		FullWidthGraphComponent

	]
})

export class WidgetComponentModule { }
