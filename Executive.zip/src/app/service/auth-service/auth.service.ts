import { Injectable } from '@angular/core';

import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

	user 		  : Observable<any>;
	userData   : any;
   isLoggedIn = false;

   constructor(
               private router : Router,
               private toastr : ToastrService) { 
   
   }

   /*
    *  getLocalStorageUser function is used to get local user profile data.
    */
   getLocalStorageUser(){
      this.userData = JSON.parse(localStorage.getItem("userProfile"));
      if(this.userData) {
         this.isLoggedIn = true;
         return true;
      } else {
         this.isLoggedIn = false;
         return false;
      }    
   }

  	/*
    * signupUserProfile method save email and password into firabse &
    * signupUserProfile method save the user sign in data into local storage. 
    */
   signupUserProfile(value) {
      this.toastr.success('Successfully Signed Up!');
      this.setLocalUserProfile(value);
      this.router.navigate(['/']);
    
   }

   /*
    * loginUser fuction used to login 
    */
   loginUser(value) {
      this.setLocalUserProfile(value);
      this.toastr.success('Successfully Logged In!');
      this.router.navigate(['/']);
     
   }

   /*
    * resetPassword is used to reset your password
    */
   resetPassword(value) {
      this.toastr.success("A password reset link has been sent to this email.");
          	this.router.navigate(['/session/login']);
      
   }


  
   /*
    * logOut function is used to sign out  
    */
   logOut() {
      localStorage.removeItem("userProfile");
      this.isLoggedIn = false;
      this.toastr.success("Successfully logged out!");
      this.router.navigate(['/session/login']);
      
      
   }   

   /*
    * setLocalUserProfile function is used to set local user profile data.
    */
   setLocalUserProfile(value){
   	localStorage.setItem("userProfile", JSON.stringify(value));
      this.getLocalStorageUser();
      this.isLoggedIn = true;
   }
}
