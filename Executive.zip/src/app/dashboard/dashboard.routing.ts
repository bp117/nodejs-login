import { Routes } from '@angular/router';

import {ExecutiveComponent} from'./executive/executive.component';

export const DashboardRoutes: Routes = [
   {
      path: '',
      redirectTo: 'executive',
      pathMatch: 'full'
   },
   {
      path: '', 
      children: [

         {
            path: "executive",
            component : ExecutiveComponent
         }
      ]
   }
];
