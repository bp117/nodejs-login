import { Component, OnInit } from '@angular/core';
import { PageTitleService } from '../../core/page-title/page-title.service';
import { CoreService } from '../../service/core/core.service';
import {pieChartDemoData,} from "../../data/widgetDemoData.data";
import 'chartjs-plugin-streaming';
import * as Chart from 'chart.js';
@Component({
  selector: 'ms-executive',
  templateUrl: './executive.component.html',
  styleUrls: ['./executive.component.scss']
})

export class ExecutiveComponent implements OnInit {
	
   tableTabData    : any;
   statsCards      : any;
   liveChatSupport : any;
   pieChartDemoData;
   
   //upcoming events content
   UpcomingEvents : any [] = [
      {
         title : "Marketing Seminar",
         date : "28th April",
         status : "Email",
         location : "Mumbai"
      },
      {
         title : "Strategy Planning",
         date : "22th May",
         status : "Phone",
         location : "Delhi"
      },
      {
         title : "Hiring Personals",
         date : "29th May",
         status : "Skype",
         location : "Delhi"
      },
      {
         title : "Training",
         date : "30th May",
         status : "Email",
         location : "Delhi"
      }
   ]

   //project status content
   projectStatus : any [] = [
      {
         title : "Project 1",
         duration : "Completed",
         color : "success-bg",
         value : 50
      },
      {
         title : "Project 2",
         duration : "Pending",
         color : "warn-bg",
         value : 60
      },
      {
         title : "Project 3",
         duration : "Ongoing",
         color : "primary-bg",
         value : 70
      },
      {
         title : "Project 4",
         duration : "Completed",
         color : "success-bg",
         value : 50
      }
   ];

   /* BarCharts*/
   public barChartLabels:string[] = ['last 15m', 'last 1h', 'last 24h', 'last 48h'];
   public barChartType:string = 'bar';
   public barChartLegend:boolean = false;

   public barChartData:any[] = [
      {data: [65, 159, 480, 881], label: '# of Requests'},
    
   ];

   public barChartOptions : any = {
      scaleShowVerticalLines : false,
      responsive : true,
      scales: {
         xAxes: [{
           stacked: true,
           ticks: {
             fontColor: 'white',  // x axe labels (can be hexadecimal too)
           },
           gridLines: {
             color: '#5f5e5e'  // grid line color (can be removed or changed)
           }
         }],
         yAxes: [{
           stacked: true,
           ticks: {
             fontColor: 'white',  // y axes numbers color (can be hexadecimal too)
             min: 0,
             beginAtZero: true,
   
           },
           gridLines: {
             color: '#white'  // grid line color (can be removed or changed)
           }
         }]
       }
   };

   barChartColors: Array <any> = [{
      backgroundColor: 'yellow',
      borderColor: 'white',
      pointBackgroundColor: 'white',
      pointBorderColor: '#000',
      pointHoverBackgroundColor: '#000',
      pointHoverBorderColor: 'white'
   }, {
   backgroundColor: 'rgba(235, 78, 54, 1)',
      borderColor: 'rgba(235, 78, 54, 1)',
      pointBackgroundColor: 'rgba(235, 78, 54, 1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(235, 78, 54, 1)'
   },{
   backgroundColor: 'rgba(67, 210, 158, 0.2)',
      borderColor: 'rgba(67, 210, 158, 1)',
      pointBackgroundColor: 'rgba(67, 210, 158, 1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(67, 210, 158, 0.8)'
   }];

   // lineChart
   public lineChartData:Array<any> = [
      {data: [90, 150, 80, 300, 90, 290, 350,200,80,100,220,230,310,230,150,180,120,150], label: 'Series A'},
      {data: [110, 90, 150, 130, 290, 210, 200,80,80,110,320,310,50,170,210,310,150,80,450], label: 'Series B'},
   ];
   public lineChartLabels:Array<any> = ['1', '2', '3', '4', '5', '6', '7','8','9','10','11','12','13','14','15','16','17','18'];
   public lineChartOptions:any = {
      responsive: true,
      scales: {
         xAxes: [{
            type: 'realtime',
            realtime: {

               onRefresh: function(chart: any) {
     
                 chart.data.datasets.forEach(function(dataset: any) {
     
                   dataset.data.push({
     
                     x: Date.now(),
     
                     y: Math.random()*100
     
                   });
     
                 });
     
               },
     
               delay: 2000
     
             }
     
           ,
            ticks: {
               beginAtZero: true,
               suggestedMax: 450
            }
         }]
      }
   };
   lineChartColors: Array <any> = [{
     // backgroundColor: 'rgba(235, 78, 54, 0.2)',
      borderColor: 'rgba(235, 78, 54, 1)',
      pointBackgroundColor: 'rgba(235, 78, 54, 1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(235, 78, 54, 0.8)'
   }, {
    //  backgroundColor: 'rgba(0, 151, 167, 0.2)',
      borderColor: 'rgba(0, 151, 167, 1)',
      pointBackgroundColor: 'rgba(0, 151, 167, 1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0, 151, 167, 0.8)'
   }];
  public lineChartLegend:boolean = false;
  public lineChartType:string = 'line';
   chartColors = {
	red: 'rgb(255, 99, 132)',
	orange: 'rgb(255, 159, 64)',
	yellow: 'rgb(255, 205, 86)',
	green: 'rgb(75, 192, 192)',
	blue: 'rgb(54, 162, 235)',
	purple: 'rgb(153, 102, 255)',
	grey: 'rgb(201, 203, 207)'
};

   /*
      ----------Project Status Chart ----------
   */
  
   // bar chart label
   public projectStatusLabel :string[] = ['Project 1', 'Project 2', 'Project 3', 'Project 4'];
   
   //bar chart data
   public projectStatusData : any[] = [
      {data: [400 ,700, 1400, 900]}
   ];

   //bar chart color
   public projectStatusColors: Array <any> = [
      {
         backgroundColor: '#1565c0',
         hoverBackgroundColor: '#6794dc'
      }
   ]

   displayedTransactionColumns : string [] = ['transid','date','account', 'type', 'amount','debit','credit', 'balance'];

   displayedTransferColumns : string [] = ['transid','date','account', 'type', 'amount', 'balance','status'];

   displayedExpenseColumns : string [] = ['itmNo','date', 'type','description','amount','status'];
  
   //notification content
   notificationContent : any = [
      {
         notification : "Site goes  down for 6 hours due to maintainance and bug fixing.Please Check",
         card_color : "warn-bg"
      },
      {
         notification : "New users from March are promoted .",
         card_color : "success-bg"
      },
      {
         notification : "Bug detected from the development team at the cart module of Fashion store.",
         card_color : "primary-bg"
      }
   ]

	constructor(private pageTitleService: PageTitleService,
               private coreService : CoreService) { }

	ngOnInit() {
      this.pageTitleService.setTitle("Executive");
      this.pieChartDemoData =pieChartDemoData;
     // window.myChart = document.getElementById("realtimeChart");
      
      

      this.coreService.getCrmStatsCardContent().
         subscribe( res => { this.statsCards = res },
                    err => console.log(err),
                   ()  => this.statsCards
         );

   }
   addSpecialDay(){
      var color = Chart.helpers.color;
      var colorNames = Object.keys(this.chartColors);
         var colorName = colorNames[this.lineChartData.length % colorNames.length];
         var newColor = this.chartColors[colorName];
         var newDataset = {
            label: 'Dataset ' + (this.lineChartData.length + 1),
            backgroundColor: color(newColor).alpha(0.5).rgbString(),
            borderColor: newColor,
            fill: false,
            lineTension: 0,
            data: []
         };
      
         this.lineChartData.push(newDataset);
         //window.myChart.update();
     
      
 
   }
   remove(){
     
      this.lineChartData.pop();
         //window.myChart.update();
    
   }
}
