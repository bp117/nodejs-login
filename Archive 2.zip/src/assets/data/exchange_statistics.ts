[
   {
      icon1 : "BTC",
      icon2 : "ETH",
      icon1_name : "Bitcoin",
      icon2_name : "Ethereum",
      icon1_color : "primary-text",
      icon2_Color : "success-text",
      price : "0.00004356",
      volume : "8.6367290",
      percentage : "86",
      chartLabel : ['9', '10', '11', '12', '13', '14', '15', '16'],
      chartData :[
         {data: [30,5,26,10,30,5,26,10],label:" Statistics"}
      ],
      chartColor :  [{
         fill: false,
         lineTension: 0,
         fillOpacity: 0.3,
         pointHoverBorderWidth: 4,
         borderWidth:4,
         pointHoverRadius: 7,
         pointBorderWidth: 3,
         pointRadius: 6,
         backgroundColor: '#1565c0',
         borderColor: '#1565c0',
         pointBackgroundColor: '#1565c0',
         pointBorderColor:'#FFFFFF',
         pointHoverBackgroundColor: '#1565c0',
         pointHoverBorderColor: '#1565c0'
      }]
   },
   {
      icon1 : "ETH",
      icon2 : "LTC",
      icon1_name : "Ethereum",
      icon2_name : "Litecoin",
      icon1_color : "success-text",
      icon2_Color : "warn-text",
      price : "0.00004356",
      volume : "8.6367290",
      percentage : "89",
      chartLabel : ['9', '10', '11', '12', '13', '14', '15', '16'],
      chartData :[
         {data: [1,26,8,22,26,8,22,1],label:" Statistics"}
      ],
      chartColor :  [{
         fill: false,
         lineTension: 0,
         fillOpacity: 0.3,
         pointHoverBorderWidth: 4,
         borderWidth:4,
         pointHoverRadius: 7,
         pointBorderWidth: 3,
         pointRadius: 6,
         backgroundColor: '#1565c0',
         borderColor: '#1565c0',
         pointBackgroundColor: '#1565c0',
         pointBorderColor:'#FFFFFF',
         pointHoverBackgroundColor: '#1565c0',
         pointHoverBorderColor: '#1565c0'
      }]
   },
   {
      icon1 : "LTC",
      icon2 : "BTC",
      icon1_name : "Litecoin",
      icon2_name : "Bitcoin",
      icon1_color : "warn-text",
      icon2_Color : "primary-text",
      price : "0.00004356",
      volume : "8.6367290",
      percentage : "84",
      chartLabel : ['9', '10', '11', '12', '13', '14', '15', '16'],
      chartData :[
         {data: [10,26,5,30,10,26,5,30],label:" Statistics"}
      ],
      chartColor :  [{
         fill: false,
         lineTension: 0,
         fillOpacity: 0.3,
         pointHoverBorderWidth: 4,
         borderWidth:4,
         pointHoverRadius: 7,
         pointBorderWidth: 3,
         pointRadius: 6,
         backgroundColor: '#1565c0',
         borderColor: '#1565c0',
         pointBackgroundColor: '#1565c0',
         pointBorderColor:'#FFFFFF',
         pointHoverBackgroundColor: '#1565c0',
         pointHoverBorderColor: '#1565c0'
      }]
   }
]