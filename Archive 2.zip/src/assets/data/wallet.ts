[
   {
      "currency" : "Bitcoin",
      "receivedAmount" : "+ 13247837654",
      "sentAmount" : "+ 13247837654",
      "totalAmount" : "+ 13247837654",
      "walletAddress" : "YXB35H24ISDJHCISDT",
      "image" : "gene-qr.jpg",
      "expandedStatus" : true
   },
   {
      "currency" : "Ethereum",
      "receivedAmount" : "+ 13247837654",
      "sentAmount" : "+ 13247837654",
      "totalAmount" : "+ 13247837654",
      "walletAddress" : "YXB35H24ISDJHCISDT",
      "image" : "gene-qr.jpg",
      "expandedStatus" : false
   },
   {
      "currency" : "Litecoin",
      "receivedAmount" : "+ 13247837654",
      "sentAmount" : "+ 13247837654",
      "totalAmount" : "+ 13247837654",
      "walletAddress" : "YXB35H24ISDJHCISDT",
      "image" : "gene-qr.jpg",
      "expandedStatus" : false
   },
   {
      "currency" : "Zcash",
      "receivedAmount" : "+ 13247837654",
      "sentAmount" : "+ 13247837654",
      "totalAmount" : "+ 13247837654",
      "walletAddress" : "YXB35H24ISDJHCISDT",
      "image" : "gene-qr.jpg",
      "expandedStatus" : false
   }
]
