import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { VendorModel } from './VendorModel';

@Injectable({
  providedIn: 'root'
})
export class VendorService {

  constructor(private http: HttpClient) { }

  baseurl: string = "http://localhost:3000/";

  getAllVendors(){
    return this.http.get<VendorModel[]>(this.baseurl + 'Vendors');
  }

  getVendorById(id: string){
    return this.http.get<VendorModel>(this.baseurl + 'Vendors' + '/' + id);
  }

  addVendor(vendor: VendorModel){
    return this.http.post(this.baseurl + 'Vendors', vendor);
  }

  deleteVendor(id: string){
    return this.http.delete(this.baseurl + 'Vendors' + '/' + id);
  }

  updateVendor(vendor: VendorModel){
    return this.http.put(this.baseurl + 'Vendors' + '/' + vendor._id, vendor);
  }
}