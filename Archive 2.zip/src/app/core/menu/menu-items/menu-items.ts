import { Injectable } from '@angular/core';

export interface ChildrenItems {
  state: string;
  name: string;
  type?: string;
}

export interface Menu {
  state: string;
  name: string;
  type: string;
  icon: string;
  children?: ChildrenItems[];
}

const MENUITEMS = [

  {
    state: 'dashboard',
    name: 'DASHBOARD',
    type: 'sub',
    label:'New',
    icon: 'explore',
    children: [
     
      {state: 'vip', name: 'VIP Dashboard'},
      
      
    ]
  },
  
  {
    state: 'user-management',
    name: 'Vendors',
    type: 'sub',
    icon: 'view_list',
    label : 'New',
    children: [
      {state: 'usermanagelist', name: 'Vendor List'}
    ]
  },
  


];

@Injectable()
export class MenuItems {
  getAll(): Menu[] {
    return MENUITEMS;
  }
  add(menu:any) {
    MENUITEMS.push(menu);
  }
}
