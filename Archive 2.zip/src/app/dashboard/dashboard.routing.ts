import { Routes } from '@angular/router';


import { SaasComponent } from './saas/saas.component';


export const DashboardRoutes: Routes = [
   {
      path: '',
      redirectTo: 'vip',
      pathMatch: 'full'
   },
   {
      path: '',
      children: [
         {
            path: 'vip',
            component: SaasComponent
         }
      ]
   }
];
