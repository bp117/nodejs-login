import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators,FormArray } from '@angular/forms';
import { MatDialogRef } from '@angular/material';
import{VendorService} from '../../../vendor.service'
@Component({
  selector: 'ms-add-new-user',
  templateUrl: './add-new-user.component.html',
  styleUrls: ['./add-new-user.component.scss']
})
export class AddNewUserComponent implements OnInit {

	addNewUserForm    : FormGroup;
	emailPattern 		: string = "^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$";

	constructor( private formBuilder : FormBuilder,
					 public dialogRef    : MatDialogRef<AddNewUserComponent>,private vendorService:VendorService) { }

	ngOnInit() {
		this.addNewUserForm = this.formBuilder.group({
			name	 : ['',[Validators.required]],
			organization 	 : ['',[Validators.required]],
			size 	 : ['',[Validators.required]],
			product 	 : ['',[Validators.required]],
			version 	 : ['',[Validators.required]],
			customerSize 	 : ['',[Validators.required]],
			emailAddress : ['',[Validators.required,Validators.pattern(this.emailPattern)]],
			interactions: this.formBuilder.array([
				// load first row at start
				this.getInteraction()
			 ]),
			
		})
	}
	  /**
   * Create form unit
   */
  private getInteraction() {
    const numberPatern = '^[0-9.,]+$';
    return this.formBuilder.group({
		meetingType 	 : ['',[Validators.required]],
		meetingDate 	 : ['',[Validators.required]],
		meetingNotes 	 : ['',[Validators.required]],
		attendees 	 : ['',[Validators.required]],
    });
  }

  /**
   * Add new unit row into form
   */
  private addUnit() {
    const control = <FormArray>this.addNewUserForm.controls['interactions'];
    control.push(this.getInteraction());
  }

  /**
   * Remove unit row from form on click delete button
   */
  private removeUnit(i: number) {
    const control = <FormArray>this.addNewUserForm.controls['interactions'];
    control.removeAt(i);
  }

	// onFormSubmit method is submit a add new user form.
	onFormSubmit(){
		this.vendorService.addVendor(this.addNewUserForm.value)
		.subscribe( data => {
		  console.log(data);
		  this.dialogRef.close(this.addNewUserForm.value);
		});
		
	}

}
