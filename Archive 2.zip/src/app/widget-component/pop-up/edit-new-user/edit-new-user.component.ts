import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder,FormArray } from '@angular/forms';
import { MatDialogRef,MatDialog} from '@angular/material';

@Component({
  selector: 'ms-edit-new-user',
  templateUrl: './edit-new-user.component.html',
  styleUrls: ['./edit-new-user.component.scss']
})
export class EditNewUserComponent implements OnInit {

	form : FormGroup
	data : any;

	constructor( public formBuilder : FormBuilder,
					 public dialogRef : MatDialogRef<EditNewUserComponent>) { }

	ngOnInit() 
		{
		this.form = this.formBuilder.group({
			name	 : [],
			organization 	 : [],
			size 	 : [],
			product 	 : [],
			version 	 : [],
			customerSize 	 : [],
			emailAddress : [],
			interactions: this.formBuilder.array([
				// load first row at start
				this.getInteraction()
			 ])
		});

		if(this.data){
			this.form.patchValue({

				name	 : this.data.name,
			organization 	 : this.data.organization,
			size 	 : this.data.size,
			product 	 : this.data.product,
			version 	 : this.data.version,
			customerSize 	 : this.data.customerSize,
			emailAddress : this.data.emailAddress,
			interactions: this.data.interactions

				
			});
		}
	}
	private getInteraction() {
		
		return this.formBuilder.group({
			meetingType 	 : [],
			meetingDate 	 : [],
			meetingNotes 	 : [],
			attendees 	 : [],
		});
	  }

	  private removeUnit(i: number) {
		const control = <FormArray>this.form.controls['interactions'];
		control.removeAt(i);
	  }
	/**
	  *onFormSubmit method is used to submit the edit new user dialaog form and close the dialog.
	  */
	onFormSubmit(){
		this.dialogRef.close(this.form.value);
	}
}