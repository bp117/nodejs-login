import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule,
			MatButtonModule,
			MatIconModule,
			MatDialogModule,
			MatFormFieldModule,
			MatSelectModule,
			MatMenuModule,
			MatDividerModule,
			MatSnackBarModule,
			MatInputModule,
			MatChipsModule,
			MatListModule,
			MatExpansionModule
		} from '@angular/material';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { TextMaskModule } from 'angular2-text-mask';
import { ChartsModule } from 'ng2-charts';
import { QuillModule } from 'ngx-quill';
import { FlexLayoutModule } from '@angular/flex-layout';
import { TranslateModule } from '@ngx-translate/core';
import { EmbedVideo } from 'ngx-embed-video';
import { BarRatingModule } from "ngx-bar-rating";
import { RouterModule } from '@angular/router';

import { SlickCarouselModule } from 'ngx-slick-carousel';
import { EasyPieChartModule } from 'ng2modules-easypiechart';
import { nvD3 } from "../core/nvD3/nvD3.component";
import { DeleteDialogComponent } from './pop-up/delete-dialog/delete-dialog.component';
import { AddNewCardComponent } from './pop-up/add-new-card/add-new-card.component';
import { InboxComposeComponent } from './pop-up/inbox-compose/inbox-compose.component';
import { AddNewUserComponent } from './pop-up/add-new-user/add-new-user.component';
import { EditNewUserComponent } from './pop-up/edit-new-user/edit-new-user.component';
import { LanguageDropDownComponent } from './global/language-drop-down/language-drop-down.component';
import { PaymentMessageComponent } from './pop-up/payment-message/payment-message.component';
import { StatsCardComponent } from './stats-card/stats-card.component';
import { TradeDialogComponent } from './pop-up/trade-dialog/trade-dialog.component';
import { AddNewClientComponent } from './pop-up/add-new-client/add-new-client.component';
import { EditNewClientComponent } from './pop-up/edit-new-client/edit-new-client.component';
import { SaleCardComponent } from './card/sale-card/sale-card.component';
import { ServerCardComponent } from './card/server-card/server-card.component';
import { SaasDashboardCardComponent } from './card/saas-dashboard-card/saas-dashboard-card.component';
import { YearlySaleComponent } from './chart/yearly-sale/yearly-sale.component';
import { EmailStatisticsComponent } from './chart/email-statistics/email-statistics.component';
@NgModule({
	declarations: [
		DeleteDialogComponent,
		AddNewCardComponent,
		nvD3,
		InboxComposeComponent,
		AddNewUserComponent,
		EditNewUserComponent,
		LanguageDropDownComponent,
		PaymentMessageComponent,
		StatsCardComponent,
		TradeDialogComponent,
		AddNewClientComponent,
		EditNewClientComponent,
		SaleCardComponent,
		ServerCardComponent,
		SaasDashboardCardComponent,
		YearlySaleComponent,
		EmailStatisticsComponent
	],
	imports: [
		RouterModule,
		BarRatingModule,
		EasyPieChartModule,
		CommonModule,
		MatCardModule,
		FlexLayoutModule,
		MatInputModule,
		MatButtonModule,
		MatIconModule,
		QuillModule,
		MatExpansionModule,
		MatDialogModule,
		MatFormFieldModule,
		MatSelectModule,
		MatMenuModule,
		MatDividerModule,
		FormsModule,
		ReactiveFormsModule,
		TextMaskModule,
		ChartsModule,
		MatSnackBarModule,
		SlickCarouselModule,
		TranslateModule,
		MatChipsModule,
		MatListModule,
		EmbedVideo.forRoot()

	],
	exports: [
		LanguageDropDownComponent,
		StatsCardComponent,
		SaleCardComponent,
		ServerCardComponent,
		SaasDashboardCardComponent,
		YearlySaleComponent,
		EmailStatisticsComponent
	],
	entryComponents : [
		DeleteDialogComponent,
		AddNewCardComponent,
		InboxComposeComponent,
		AddNewUserComponent,
		EditNewUserComponent,
		PaymentMessageComponent,
		TradeDialogComponent,
		AddNewClientComponent,
		EditNewClientComponent
	]
})

export class WidgetComponentModule { }
