export class VendorModel {
    _id: string;
    name: String;
    organization: String;
    size: number;
    meetingType: string;
    meetingNotes:string;
    productName:string;
    version:number;
    noofcustomers:number;
    interactions:Interactions;
}

export class Interactions{
    _id:string;
    meetingType 	 : string;
			meetingDate 	 : string;
			meetingNotes 	 : string;
			attendees 	 : string
}