module.exports = {
  port: process.env.PORT || 7002,
  loglevel: 'info'
};