import Responder from '../../lib/expressResponder';
import Component from '../models/component';
import _ from "lodash";


export default class ComponentController {
  static show(req, res) {
    Component.find(req.body)
    .then((component)=> {
    Responder.success(res,component)
    })
    .catch((err)=>Responder.operationFailed(res,err))
  }

  static create(req, res) {
    Component.create(req.body)
    .then((component)=>Responder.success(res,component))
    .catch((err)=>Responder.operationFailed(res,err))
  }
  static update(req, res) {
    Component.findOneAndUpdate({_id:req.params.id},{$set:req.body},{new:true})
      .then((val)=>Responder.success(res,val))
      .catch((err)=>Responder.operationFailed(res,err))
  }

  static remove(req, res) {
    Component.remove({_id:req.params.id})
    .then((component)=>Responder.success(res,component))
    .catch((err)=>Responder.operationFailed(res,err))
  }

}
