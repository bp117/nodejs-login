import Responder from '../../lib/expressResponder';
import Application from '../models/application';
import _ from "lodash";


export default class ApplicationController {
  static show(req, res) {
    Application.find(req.body)
    .then((application)=> {
    Responder.success(res,application)
    })
    .catch((err)=>Responder.operationFailed(res,err))
  }

  static create(req, res) {
    Application.create(req.body)
    .then((application)=>Responder.success(res,application))
    .catch((err)=>Responder.operationFailed(res,err))
  }
  static update(req, res) {
    Application.findOneAndUpdate({_id:req.params.id},{$set:req.body},{new:true})
      .then((val)=>Responder.success(res,val))
      .catch((err)=>Responder.operationFailed(res,err))
  }

  static remove(req, res) {
    Application.remove({_id:req.params.id})
    .then((application)=>Responder.success(res,application))
    .catch((err)=>Responder.operationFailed(res,err))
  }

}
