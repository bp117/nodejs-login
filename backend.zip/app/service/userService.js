import User from '../models/user';

export default class UserService {
  static updateUser(userId, chat) {
    return User.findOneAndUpdate({_id:userId},{$set:{chat}})
    
        
  }
  static updateLastSeen(userId) {
    return User.findOneAndUpdate({_id:userId},{$set:{chat:{online:false,lastSeen:new Date()}}})
    
        
  }
}
