import mongoose from 'mongoose';
const Schema = mongoose.Schema;


const UserSchema = new Schema({
    teamId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Team'
    },
    userName:String,
    emailContact:String,
    lanId:String,
    userRole: String
});


export default mongoose.model('User', UserSchema);
