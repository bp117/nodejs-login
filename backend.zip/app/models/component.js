import mongoose from 'mongoose';
const Schema = mongoose.Schema;


const ComponentSchema = new Schema({
    applicationId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Application'
    },
    componentName: String,
    dependencies: [{
        dependencyType: String,
        componentId: String,
        application:[]
    }]
});


export default mongoose.model('Component', ComponentSchema);
