import mongoose from 'mongoose';
const Schema = mongoose.Schema;


const ServerSchema = new Schema({
    componentId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Component'
    },
    serverName: String,
});


export default mongoose.model('Server', ServerSchema);
