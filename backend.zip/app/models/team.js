import mongoose from 'mongoose';
const Schema = mongoose.Schema;


const instance = new Schema({
    instanceNo:String,
    startupCommand:String,
    shutdownCommand:String,
    queryCommand:String
});

const release = new Schema({
    releaseName:String,
    env:String,
    instanceCommands: [instance]
});

const server = new Schema({
    serverName: String,
    release: [release]
});

const component = new Schema({
    componentName: String,
    servers: [server],
    dependencies: [{
        dependencyType: String,
        componentId: Object,
        application:[{applicationId: Object}]
    }]
});

const application = new Schema({
    appName:String,
    remedyAppId:String,
    emailContact:String,
    components: [component]
});

const user = new Schema({
    userName:String,
    emailContact:String,
    lanId:String,
    userRole: String,
    applications: [application]
});


const chaosTeamSchema = new Schema({
    teamName: String,
    lob: String,
    subLob: String,
    emailContact: String,
   // users: [user]
    },
    {
    timestamps: true
});


export default mongoose.model('Team', chaosTeamSchema);