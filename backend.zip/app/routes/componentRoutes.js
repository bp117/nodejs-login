import express from 'express';
import ComponentController from '../controllers/componentController';

const initComponentRoutes = () => {
  const componentRoutes = express.Router();
  componentRoutes.get('/', ComponentController.show);
  componentRoutes.post('/', ComponentController.create);
  componentRoutes.put('/:id', ComponentController.update);
  componentRoutes.delete('/:id', ComponentController.remove);
  return componentRoutes;
};

export default initComponentRoutes;
