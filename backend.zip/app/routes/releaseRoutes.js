import express from 'express';
import ReleaseController from '../controllers/releaseController';

const initReleaseRoutes = () => {
  const releaseRoutes = express.Router();
  releaseRoutes.get('/', ReleaseController.show);
  releaseRoutes.post('/', ReleaseController.create);
  releaseRoutes.put('/:id', ReleaseController.update);
  releaseRoutes.delete('/:id', ReleaseController.remove);
  return releaseRoutes;
};

export default initReleaseRoutes;
