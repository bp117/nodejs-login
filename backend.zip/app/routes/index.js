import initTeamRoutes from './teamRoutes';
import initAttackRoutes from './attackRoutes';
import initAttackRunRoutes from './attackRunRoutes';
import initUserRoutes from './userRoutes';
import initApplicationRoutes from './applicationRoutes';
import initComponentRoutes from './componentRoutes';
import initServerRoutes from './serverRoutes';
import initReleaseRoutes from './releaseRoutes';
import initInstanceRoutes from './instanceRoutes';

const initRoutes = (app) => {
  app.use(`/team`, initTeamRoutes());
  app.use(`/attack`,initAttackRoutes());
  app.use(`/attackRun`, initAttackRunRoutes());
  app.use(`/user`, initUserRoutes());
  app.use(`/application`, initApplicationRoutes());
  app.use(`/component`, initComponentRoutes());
  app.use(`/server`, initServerRoutes());
  app.use(`/release`, initReleaseRoutes());
  app.use(`/instance`, initInstanceRoutes());
 
  
  // set the static files location /public/img will be /img for users
  // app.get('/', function(req, res) {  });


};

export default initRoutes;
