import Responder from '../../lib/expressResponder';
import Server from '../models/server';
import _ from "lodash";


export default class ServerController {
  static show(req, res) {
    let page = req.body.page || 1;
    let limit =  req.body.limit || 10;
    delete req.body.page;
    delete req.body.limit;
    Server.find(req.body)
    .skip((page-1)*limit)
    .limit(limit)
    .then((server)=> {
    Responder.success(res,server)
    })
    .catch((err)=>Responder.operationFailed(res,err))
  }

  static create(req, res) {
    Server.create(req.body)
    .then((server)=>Responder.success(res,server))
    .catch((err)=>Responder.operationFailed(res,err))
  }
  static update(req, res) {
    Server.findOneAndUpdate({_id:req.params.id},{$set:req.body},{new:true})
      .then((val)=>Responder.success(res,val))
      .catch((err)=>Responder.operationFailed(res,err))
  }

  static remove(req, res) {
    Server.remove({_id:req.params.id})
    .then((server)=>Responder.success(res,server))
    .catch((err)=>Responder.operationFailed(res,err))
  }

}
