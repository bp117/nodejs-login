import Responder from '../../lib/expressResponder';
import Application from '../models/application';
import _ from "lodash";


export default class ApplicationController {
  static show(req, res) {
    let page = req.body.page || 1;
    let limit =  req.body.limit || 10;
    delete req.body.page;
    delete req.body.limit;
    Application.find(req.body)
    .skip((page-1)*limit)
    .limit(limit)
    .then((application)=> {
    Responder.success(res,application)
    })
    .catch((err)=>Responder.operationFailed(res,err))
  }

  static create(req, res) {
    Application.create(req.body)
    .then((application)=>Responder.success(res,application))
    .catch((err)=>Responder.operationFailed(res,err))
  }
  static update(req, res) {
    Application.findOneAndUpdate({_id:req.params.id},{$set:req.body},{new:true})
      .then((val)=>Responder.success(res,val))
      .catch((err)=>Responder.operationFailed(res,err))
  }

  static remove(req, res) {
    Application.remove({_id:req.params.id})
    .then((application)=>Responder.success(res,application))
    .catch((err)=>Responder.operationFailed(res,err))
  }

}
