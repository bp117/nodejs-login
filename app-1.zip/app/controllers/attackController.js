import Responder from '../../lib/expressResponder';
import Attack from '../models/attack';
import _ from "lodash";


export default class AttackController {
  static show(req, res) {
    let page = req.body.page || 1;
    let limit =  req.body.limit || 10;
    delete req.body.page;
    delete req.body.limit;
    Attack.find(req.body)
    .skip((page-1)*limit)
    .limit(limit)
    .then((attack)=> {
    Responder.success(res,attack)
    })
    .catch((err)=>Responder.operationFailed(res,err))
  }

  static create(req, res) {
    Attack.create(req.body)
    .then((attack)=>Responder.success(res,attack))
    .catch((err)=>Responder.operationFailed(res,err))
  }
  static update(req, res) {
    Attack.findOneAndUpdate({_id:req.params.id},{$set:req.body},{new:true})
      .then((val)=>Responder.success(res,val))
      .catch((err)=>Responder.operationFailed(res,err))
  }

  static remove(req, res) {
    Attack.remove({_id:req.params.id})
    .then((attack)=>Responder.success(res,attack))
    .catch((err)=>Responder.operationFailed(res,err))
  }

}
