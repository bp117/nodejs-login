import Responder from '../../lib/expressResponder';
import Release from '../models/release';
import _ from "lodash";


export default class ReleaseController {
  static show(req, res) {
    let page = req.body.page || 1;
    let limit =  req.body.limit || 10;
    delete req.body.page;
    delete req.body.limit;
    Release.find(req.body)
    .skip((page-1)*limit)
    .limit(limit)
    .then((release)=> {
    Responder.success(res,release)
    })
    .catch((err)=>Responder.operationFailed(res,err))
  }

  static create(req, res) {
    Release.create(req.body)
    .then((release)=>Responder.success(res,release))
    .catch((err)=>Responder.operationFailed(res,err))
  }
  static update(req, res) {
    Release.findOneAndUpdate({_id:req.params.id},{$set:req.body},{new:true})
      .then((val)=>Responder.success(res,val))
      .catch((err)=>Responder.operationFailed(res,err))
  }

  static remove(req, res) {
    Release.remove({_id:req.params.id})
    .then((release)=>Responder.success(res,release))
    .catch((err)=>Responder.operationFailed(res,err))
  }

}
