import Responder from '../../lib/expressResponder';
import Component from '../models/component';
import _ from "lodash";


export default class ComponentController {
  static show(req, res) {
    let page = req.body.page || 1;
    let limit =  req.body.limit || 10;
    delete req.body.page;
    delete req.body.limit;
    Component.find(req.body)
    .skip((page-1)*limit)
    .limit(limit)
    .then((component)=> {
    Responder.success(res,component)
    })
    .catch((err)=>Responder.operationFailed(res,err))
  }

  static create(req, res) {
    Component.create(req.body)
    .then((component)=>Responder.success(res,component))
    .catch((err)=>Responder.operationFailed(res,err))
  }
  static update(req, res) {
    Component.findOneAndUpdate({_id:req.params.id},{$set:req.body},{new:true})
      .then((val)=>Responder.success(res,val))
      .catch((err)=>Responder.operationFailed(res,err))
  }

  static remove(req, res) {
    Component.remove({_id:req.params.id})
    .then((component)=>Responder.success(res,component))
    .catch((err)=>Responder.operationFailed(res,err))
  }

  static getDependentComponents(req, res) {
    let page = req.body.page || 1;
    let limit =  req.body.limit || 10;
    delete req.body.page;
    delete req.body.limit;
    Component.findOne(req.body)
    .skip((page-1)*limit)
    .limit(limit)
    .then((component)=> {
      Component.find({_id:{$in:_.map(component.dependencies,'componentId')}}).then(dependencies=>Responder.success(res,dependencies))
    
    })
    .catch((err)=>Responder.operationFailed(res,err))
  }

}
