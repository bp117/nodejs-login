import mongoose from 'mongoose';
const Schema = mongoose.Schema;


const ApplicationSchema = new Schema({
    teamId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Team'
    },
    appName:String,
    remedyAppId:String,
    emailContact:String
});


export default mongoose.model('Application', ApplicationSchema);
