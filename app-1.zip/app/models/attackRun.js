import mongoose from 'mongoose';
const Schema = mongoose.Schema;


const ChaosAttacksRunStatusSchema = new Schema({
    attackId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Attack'
    },
    runId: String,
    componentStatus: [new Schema({
    componentId: Object,
    instances: [{
    instanceId: Object,
    createDate: Date,
    status: String
    }]
    })]
    },
    {
    timestamps: true
});

export default mongoose.model('AttackRun', ChaosAttacksRunStatusSchema);
