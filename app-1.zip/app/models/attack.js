import mongoose from 'mongoose';
const Schema = mongoose.Schema;


const ChaosAttackSchema = new Schema({
    components: [],
    applicationId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Application'
    },
    summary: String,
    description:String,
    scheduledTimeStamp: Date,
    stopTimeStamp: Date,
    starTimeStamp: Date,
    createdBy: Object
    },
    {
    timestamps: true
});


export default mongoose.model('Attack', ChaosAttackSchema);
