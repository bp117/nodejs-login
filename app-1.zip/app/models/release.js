import mongoose from 'mongoose';
const Schema = mongoose.Schema;


const ReleaseSchema = new Schema({
    serverId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Server'
    },
    releaseName:String,
    env:String
});


export default mongoose.model('Release', ReleaseSchema);
