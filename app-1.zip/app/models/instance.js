import mongoose from 'mongoose';
const Schema = mongoose.Schema;


const InstanceSchema = new Schema({
    releaseId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Release'
    },
    instanceNo:String,
    startupCommand:String,
    shutdownCommand:String,
    queryCommand:String
});


export default mongoose.model('Instance', InstanceSchema);
