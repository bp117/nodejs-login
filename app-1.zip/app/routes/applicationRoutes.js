import express from 'express';
import ApplicationController from '../controllers/applicationController';

const initApplicationRoutes = () => {
  const applicationRoutes = express.Router();
  applicationRoutes.post('/get', ApplicationController.show);
  applicationRoutes.post('/', ApplicationController.create);
  applicationRoutes.put('/:id', ApplicationController.update);
  applicationRoutes.delete('/:id', ApplicationController.remove);
  return applicationRoutes;
};

export default initApplicationRoutes;
