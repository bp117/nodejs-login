import express from 'express';
import ComponentController from '../controllers/componentController';

const initComponentRoutes = () => {
  const componentRoutes = express.Router();
  componentRoutes.post('/get', ComponentController.show);
  componentRoutes.post('/', ComponentController.create);
  componentRoutes.put('/:id', ComponentController.update);
  componentRoutes.delete('/:id', ComponentController.remove);
  componentRoutes.post('/getDependentComponents', ComponentController.getDependentComponents);
  return componentRoutes;
};

export default initComponentRoutes;
