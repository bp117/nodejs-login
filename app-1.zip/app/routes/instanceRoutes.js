import express from 'express';
import InstanceController from '../controllers/instanceController';

const initInstanceRoutes = () => {
  const instanceRoutes = express.Router();
  instanceRoutes.post('/get', InstanceController.show);
  instanceRoutes.post('/', InstanceController.create);
  instanceRoutes.put('/:id', InstanceController.update);
  instanceRoutes.delete('/:id', InstanceController.remove);
  return instanceRoutes;
};

export default initInstanceRoutes;
