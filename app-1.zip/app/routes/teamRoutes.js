import express from 'express';
import TeamController from '../controllers/teamController';

const initTeamRoutes = () => {
  const teamRoutes = express.Router();
  teamRoutes.post('/get', TeamController.show);
  teamRoutes.post('/', TeamController.create);
  teamRoutes.put('/:id', TeamController.update);
  teamRoutes.delete('/:id', TeamController.remove);
  teamRoutes.put('/user/:id', TeamController.updateUser);
  return teamRoutes;
};

export default initTeamRoutes;
