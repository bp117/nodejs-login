import express from 'express';
import AttackController from '../controllers/attackController';

const initAttackRoutes = () => {
  const attackRoutes = express.Router();
  attackRoutes.post('/get', AttackController.show);
  attackRoutes.post('/', AttackController.create);
  attackRoutes.put('/:id', AttackController.update);
  attackRoutes.delete('/:id', AttackController.remove);
  return attackRoutes;
};

export default initAttackRoutes;
