import { Injectable } from '@angular/core';

export interface ChildrenItems {
  state: string;
  name: string;
  type?: string;
}

export interface Menu {
  state: string;
  name: string;
  type: string;
  icon: string;
  children?: ChildrenItems[];
}

const MENUITEMS = [
   {
    state: 'horizontal',
    name: 'TOP MENU',
    type: 'button',
    icon: 'horizontal_split',
    label: 'New'
  },
  {
    state: 'dashboard',
    name: 'DASHBOARD',
    type: 'sub',
    label:'New',
    icon: 'explore',
    children: [
     
      {state: 'saas', name: 'VIP Dashboard'},
      
      
    ]
  },
  
  {
    state: 'user-management',
    name: 'Vendors',
    type: 'sub',
    icon: 'view_list',
    label : 'New',
    children: [
      {state: 'usermanagelist', name: 'VENDOR LIST'}
    ]
  },
  


];

@Injectable()
export class MenuItems {
  getAll(): Menu[] {
    return MENUITEMS;
  }
  add(menu:any) {
    MENUITEMS.push(menu);
  }
}
