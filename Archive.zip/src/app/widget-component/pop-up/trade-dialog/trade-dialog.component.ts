import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ms-trade-dialog',
  templateUrl: './trade-dialog.component.html',
  styleUrls: ['./trade-dialog.component.scss']
})
export class TradeDialogComponent implements OnInit {
	
	data : any;

	constructor() { }

	ngOnInit() {
	}

}
