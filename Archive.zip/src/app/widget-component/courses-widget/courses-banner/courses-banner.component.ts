import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ms-courses-banner',
  templateUrl: './courses-banner.component.html',
  styleUrls: ['./courses-banner.component.scss']
})
export class CoursesBannerComponent implements OnInit {

	constructor() { }

	ngOnInit() {
	}

}
