import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-social-share-icons',
  templateUrl: './social-share-icons.component.html',
  styleUrls: ['./social-share-icons.component.scss']
})
export class SocialShareIconsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
