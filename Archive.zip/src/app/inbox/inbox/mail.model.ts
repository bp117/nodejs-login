export class Mail {
  from: string;
  date: string;
  subject: string;
  id: number;
}

