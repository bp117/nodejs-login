import { Mail } from './mail.model';

/* tslint:disable:max-line-length */
export let demoMails: Mail[] = [{
  from: 'Vic Smith',
  date: 'Apr 15',
  subject: 'Am done my task you need to be check and give feedback ASAP! also check atteched pdf',
  id: 1
}, {
  from: 'Gyanna Hugh',
  date: 'Apr 13',
  subject: 'Upload Project Backup ,take a look and forward to the client and Sr.Manager',
  id: 2
}, {
  from: 'Dipity White',
  date: 'Apr 11',
  subject: 'Sending you the list of the students who are shortlised in the interview.Please check.',
  id: 3
}, {
  from: 'Lara Cross',
  date: 'Apr 9',
  subject: 'Presentation gone well ,now waiting for the feedback from the client side.Check Pics !',
  id: 4
}, {
  from: 'Mick Wann',
  date: 'Apr 5',
  subject: 'Grab the offers on this site ,I got 60% off on this Product pls take a look.Amzing offers',
  id: 5
}, {
  from: 'Gream Shoun',
  date: 'Apr 5',
  subject: 'Its time to to better when we have a big opportunity in our hand. Check attacted Pdf',
  id: 6
}, {
  from: 'Harry Golmes',
  date: 'Apr 5',
  subject: 'Cant Get the email from your side pls let us know you interested or not.Send ASAP',
  id: 7
}, {
  from: 'Mary King',
  date: 'Apr 3',
  subject: 'Party Plan! This weekend we will join by Mr. Smith after presentation we Do party.Good Luck',
  id: 8
}, {
  from: 'Anna Petter',
  date: 'March 28',
  subject: 'There is problem regarding the server thats why you cant get your site online.Contact Your Host',
  id: 9
}, {
  from: 'Jose Robb',
  date: 'March 26',
  subject: 'Thanks for becoming the part of our company. Mr. Johnson will reach there.Good Luck',
  id: 10
}];
