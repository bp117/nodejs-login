window['CKEDITOR_BASEPATH'] = 'http://cdn.ckeditor.com/4.6.0/full/';
